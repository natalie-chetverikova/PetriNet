package ua.com.handcrafted.petri.matrix;

/**
 * @author Someone
 * ������� �� �����
 *
 */
public class IntegerMatrix {
	private Matrix matrix;
	private Integer[][] objectMatrix;
	
	public IntegerMatrix(Matrix matrix) {
		super();
		this.matrix = matrix;
		int[][] m = matrix.getMatrix();
		for (int i = 0; i<matrix.getRowDimension(); i++) {
			for (int j = 0; i<matrix.getColumnDimension(); j++) {
				
			}
			
		}
	}
	
}
