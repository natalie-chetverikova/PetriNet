package ua.com.handcrafted.petri.matrix;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.*;
import javax.swing.table.*;

import java.util.Vector;


public class RowHeaderTable
{
    public static void main(String[] args)
    {
    	int n = 6;
    	String [] cols = new String[6];
    	for (int i=0; i<n; i++) {
    		StringBuilder sb = new StringBuilder();
    		sb.append("T");
    		sb.append(i);
    		cols[i] = sb.toString();
    	}
    	
        DefaultTableModel headerData = new DefaultTableModel(new String[] { "", }, 0);
        DefaultTableModel data = new DefaultTableModel(cols, 0);

        for (int i = 0; i < n; i++)
        {
            headerData.addRow(new Object[] { "P"+i } );

            Vector v = new Vector();

            for (int k = 0; k < 6; k++)
                v.add(new Float(k / (float)i));

            data.addRow(v);
        }

        JTable table = new JTable(data);

        JTable rowHeader = new JTable(headerData);

        LookAndFeel.installColorsAndFont
            (rowHeader, "TableHeader.background", 
            "TableHeader.foreground", "TableHeader.font");

        
        rowHeader.setIntercellSpacing(new Dimension(0, 0));
        Dimension d = rowHeader.getPreferredScrollableViewportSize();
        d.width = rowHeader.getPreferredSize().width;
        rowHeader.setPreferredScrollableViewportSize(d);
        rowHeader.setRowHeight(table.getRowHeight());
        rowHeader.setDefaultRenderer(Object.class, new RowHeaderRenderer());
        
        JScrollPane scrollPane = new JScrollPane(table);
        
        scrollPane.setRowHeaderView(rowHeader);

        JTableHeader corner = rowHeader.getTableHeader();
        corner.setReorderingAllowed(false);
        corner.setResizingAllowed(false);

        scrollPane.setCorner(JScrollPane.UPPER_LEFT_CORNER, corner);

        new JScrollPaneAdjuster(scrollPane);

        new JTableRowHeaderResizer(scrollPane).setEnabled(true); 

        JFrame f = new JFrame("Row Header Test");

        f.getContentPane().add(scrollPane, BorderLayout.CENTER);

        f.pack();
        f.setLocation(200, 100);
        f.setVisible(true);
    }
}
