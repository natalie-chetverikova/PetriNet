package ua.com.handcrafted.petri.graph;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import org.w3c.dom.Document;


import com.mxgraph.io.mxCodec;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.util.mxEventObject;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxEventSource.mxIEventListener;
import com.mxgraph.view.mxGraph;

/**
 * 
 */
public class mxTreeGraphComponent extends mxGraphComponent
{

	BackUpCellsValue backUpCellsValue; 
	/**
	 * 
	 * @param graph
	 */
	public mxTreeGraphComponent(mxGraph graph)
	{
		super(graph);

		// Sets switches typically used in an editor
		setPageVisible(false);
		setGridVisible(true);
		setToolTips(false);
		getConnectionHandler().setCreateTarget(false);
		setEnabled(false);

		// Loads the defalt stylesheet from an external file
		mxCodec codec = new mxCodec();
		Document doc = mxUtils
				.loadDocument(CustomGraphEditor.class
						.getResource(
								"/com/mxgraph/swing/examples/resources/default-style.xml")
						.toString());
		codec.decode(doc.getDocumentElement(), graph.getStylesheet());
		
		// Sets the background to white
		getViewport().setOpaque(false);
		setBackground(Color.WHITE);
		
		backUpCellsValue = new BackUpCellsValue(graph);
	}
}