/**
 * $Id: mxMouseControl.java,v 1.1 2008/09/26 14:47:40 gaudenz Exp $
 * Copyright (c) 2008, Gaudenz Alder
 */
package com.mxgraph.swing.util;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;

/**
 *
 */
public class mxMouseControl extends JComponent implements MouseMotionListener,
		MouseListener
{

	public void mouseDragged(MouseEvent e)
	{
		// empty
	}

	public void mousePressed(MouseEvent e)
	{
		// empty
	}

	public void mouseReleased(MouseEvent e)
	{
		// empty
	}

	public void mouseMoved(MouseEvent e)
	{
		// empty
	}

	public void mouseClicked(MouseEvent e)
	{
		// empty
	}

	public void mouseEntered(MouseEvent e)
	{
		// empty
	}

	public void mouseExited(MouseEvent e)
	{
		// empty
	}

}
